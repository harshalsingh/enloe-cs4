//Harshal Singh

#include<iostream>
#include<vector>
#include<algorithm>

using namespace std;

class Binary{
    private:
        vector<int>B1;
        vector<int>B2;
        int rshift;

    public:
        void input();
        void display();

        void operator ! ();
        void operator > (int rshift);
        //void operator ? (Binary);
};
