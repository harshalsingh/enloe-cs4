#include<iostream>
#include<algorithm>
#include<vector>
#include<time.h>
#include<stdio.h>
#include<stdlib.h>

using namespace std;

const int vectorsize=7;

void sethand(vector <int> &hand){
    int card,counter;
    card=0;
    srand (time(NULL));
    counter=0;

    do{
        card=rand()%9;
        hand.push_back(card);
        counter++;
    }while(counter<vectorsize);

}

void display(vector<int> hand){

    for(int c=0; c<hand.size(); c++){
        if(hand[c]==hand[c+1]){
            cout<<hand[c];
        }
        else{
            cout<<hand[c]<<" ";
        }
    }
    cout<<endl;
}

vector <int> laydown(vector <int> &hand){
    int numcard=0;
    int counter=0;
    int position;
    int typecard;

    do{
        if(hand[counter]==hand[counter+1]){
            numcard++;
        }
        else{
            numcard=0;
        }
        counter++;
    }while((counter<=hand.size())&&(numcard<3));

    position=counter-numcard;

    typecard=hand[counter];
    counter=0;
    if(numcard>=3){
        for(int c=0; c<=hand.size(); c++){
            if(hand.size()==0){

            }

            else if(hand[c]==typecard){
                if(hand.back()==typecard){
                    hand.erase(hand.begin()+c,hand.begin()+hand.size());
                    break;
                }
                else{
                    hand.erase(hand.begin()+c);
                    c--;
                }
            }
            else{

            }
        }
    }
    return hand;
}

vector<int>play(vector<int>&askhand, vector<int>&givehand, int turn){

    int askedcard=0;
    int counter=0;
    int num_cards_togive=0;
    bool checkedaskhand=false;
    bool checkedgivehand=false;
    int comppick;
    int newsize=0;

    if(turn==0){
        if (askhand.size()==1){
            comppick=0;
        }
        else{
            comppick=(rand()%(askhand.size()-1));
        }
        askedcard=askhand[comppick];
        cout<<"The computer asked for a "<<askhand[comppick]<<endl;
        for(int c=0; c<=givehand.size(); c++){
            if(givehand[c]==askedcard){
                counter=c;
                c=givehand.size()+1;
                checkedgivehand=true;
            }
            else if (givehand[c]!=askedcard){
                checkedgivehand=false;
            }
        }
    //take humans cards or draw
        if(checkedgivehand==true){
            cout<<"You had that card."<<endl;
                 for(int c=0; c<=givehand.size(); c++){
                     if(givehand[c]==askedcard){
                        if(givehand.back()==askedcard){
                            newsize=givehand.size();
                            givehand.erase(givehand.begin()+c,givehand.begin()+givehand.size());
                            num_cards_togive=newsize-c;
                            //cout<<num_cards_togive<<endl;
                            break;
                        }
                        else{
                            givehand.erase(givehand.begin()+c);
                            c--;
                            num_cards_togive++;
                        }
                    }
                    else{

                    }
                }
                for(int c=0;c<num_cards_togive;c++){
                    askhand.push_back(askedcard);
                }
                givehand.push_back(rand()%9);
            }
        else if(checkedgivehand==false){
            cout<<"You did not have that card. The Computer drew."<<endl;
            askhand.push_back(rand()%9);
        }
    }
    else if (turn==1){
        //human
        cout<<"What card do you want to ask for"<<endl;
        cin>>askedcard;
        for(int c=0; c<=askhand.size(); c++){
            if(askhand[c]==askedcard){
                checkedaskhand=true;

            }
        }

        //Check the computers hand
        if (checkedaskhand==true){
            for(int c=0; c<=givehand.size(); c++){
                if(givehand[c]==askedcard){

                    counter=c;
                    c=givehand.size()+1;
                    checkedgivehand=true;
                }
                else if (givehand[c]!=askedcard){
                    checkedgivehand=false;
                }
            }

        }
        else{
            cout<<"You do not have this card"<<endl;
            checkedgivehand=false;
        }

        //take computers cards or draw
        if(checkedgivehand==true){
             for(int c=0; c<=givehand.size(); c++){
                 if(givehand[c]==askedcard){
                    if(givehand.back()==askedcard){
                        newsize=givehand.size();
                        givehand.erase(givehand.begin()+c,givehand.begin()+givehand.size());

                        num_cards_togive=newsize+c;
                        break;
                    }
                    else{
                        givehand.erase(givehand.begin()+c);
                        c--;
                        num_cards_togive++;
                    }
                }
                else{

                }
            }
            for(int c=0;c<num_cards_togive;c++){
                askhand.push_back(askedcard);
            }
            givehand.push_back(rand()%9);
        }
        else if(checkedgivehand==false&&checkedaskhand==true){
            cout<<"The opponent does not have that card. You drew."<<endl;
            askhand.push_back(rand()%9);
        }


    }
    sort(askhand.begin(),askhand.end());
    sort(givehand.begin(),givehand.end());
    return askhand;
}

int main(){

    vector <int> hvector;
    vector <int> cvector;
    int turn;
    //cout<<"Whose turn is it? 0-Computer, 1-Human"<<endl;
    //cin>>turn;

    sethand(hvector);
    //hvector.push_back(5);
    //hvector.push_back(5);
    //hvector.push_back(7);
    //hvector.push_back(8);
    //hvector.push_back(9);
    //hvector.push_back(3);
    //hvector.push_back(9);
    cout<<"Your hand: "
    display(hvector);
    cout<<endl;
    sethand(cvector);
    cout<<"Computers hand: "
    display(cvector);
    sort(hvector.begin(),hvector.end());
    display(hvector);


    //cvector.push_back(8);
    //cvector.push_back(8);
    //cvector.push_back(9);
    //cvector.push_back(3);
    //cvector.push_back(5);
    //cvector.push_back(5);
    //cvector.push_back(5);

    sort(cvector.begin(),cvector.end());
    display(cvector);



    /*do{
        cout<<"Your cards:";
        display(hvector);

        laydown(hvector);
        cout<<"Your cards:";
        display(hvector);

        cout<<"Computers Cards:";
        display(cvector);
        cout<<"Computers Cards:";
        laydown(cvector);

        display(cvector);

        cout<<endl;

        if(turn==0){
            play(cvector,hvector,turn);
            turn=1;
            if (cvector.size()==0){

            }
            else{
                laydown(cvector);
            }
        }

        else {
            play(hvector,cvector,turn);
            turn=0;

            if (hvector.size()==0){

            }
            else{
                laydown(hvector);
            }
        }

    }while(hvector.size()>0&&cvector.size()>0);

    if(hvector.size()<=0){
        cout<<"You won"<<endl;
    }
    else if (cvector.size()<=0){
        cout<<"The computer won"<<endl;
    }
    */
    return 0;

}
