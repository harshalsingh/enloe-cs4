//Harshal Singh

#include<iostream>
#include<vector>

using namespace std;

void getcoord(int input){
    int i,j;
    i=input%7;
    if(i==0){
        i+=7;
    }
    j=(input-input%7)/7+1;
    if(j==8){
        j--;
    }

    cout<<i<<" "<<j<<endl;
}

int getx(int input){
    int x;
    x=input%7;
    if(x==0){
        x=7;
    }
    return x;
}

int gety(int input){
    int y;
    y=(input-input%7)/7+1;
    if(y==8){
        y--;
    }
    return y;
}

void setboard(int board [7][7]){
    for(int c=0;c<7;c++){
        for(int s=0;s<7;s++){
            board[c][s]=0;
        }
    }
}

void setboard2(int board[7][7]){
    int counter=1;
    for(int c=0;c<7;c++){
        for(int k=0;k<7;k++){
            board[k][c]=counter;
            counter++;
        }
    }
}


int main(){

    int input,pivot,temp,counter;
    bool empty=false;
    int differences[7];
    vector<int> pieces;
    vector<int> diff[7];


    while(input!=0){
        cin>>input;
        pieces.push_back(input);
    }

    pivot=pieces[1];
    while(empty==false){//DIRECTLY UP
        for(int c=0;c<pieces.size()-1;c++){
            if(pieces[c]==pivot+7||pivot+7>49){
                empty=true;
            }
        }
        if(empty==false){
            diff[0].push_back(pivot+7);
            pivot+=7;
        }
    }

    pivot=pieces[1];empty=false;
    while(empty==false){//DIAGONALLY UPRIGHT

        for(int c=0;c<pieces.size()-1;c++){
            if(pieces[c]==pivot+8||pivot%7==0){
                empty=true;
            }
        }
        if(empty==false){
            diff[1].push_back(pivot+8);
            pivot+=8;
        }
    }

    pivot=pieces[1];empty=false;
    while(empty==false){//RIGHT

        for(int c=0;c<pieces.size()-1;c++){
            if(pieces[c]==pivot+1||pivot%7==0){
                empty=true;
            }
        }
        if(empty==false){
            diff[2].push_back(pivot+1);
            pivot+=1;
        }
    }


    cout<<"up"<<diff[0].size()<<endl;
    cout<<"diagupright"<<diff[1].size()<<endl;
    cout<<"right"<<diff[2].size();


    return 0;
}
