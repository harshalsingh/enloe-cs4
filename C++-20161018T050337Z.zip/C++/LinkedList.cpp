//Harshal Singh

#include <iostream>

using namespace std;

class ListNode{
    private:
        int data;
        ListNode *next;
    public:
        ListNode(int d,ListNode *n){
            data=d;
            next=n;
        }
        int getData(){
            return data;
        }
        ListNode *getNext(){
            return next;
        }
        void setNext(ListNode *n){
            next=n;
        }
};

class List{
    private:
        ListNode *first;
    public:
        List(){
            first=NULL;
        }
        void print();
        void insert(int x);
        void menu();
};

void List::print(){
    ListNode *curr=first;
    do{
        cout<<curr->getData();
        cout<<" ";
        curr=curr->getNext();
    }while(curr!=NULL);
    cout<<endl;
}

void List::insert(int x){
    ListNode *newbie;
    bool sorted=false;

    newbie=new ListNode(x,NULL);

    if(first==NULL){
        first=new ListNode(x,NULL);
    }

    else{
        ListNode *curr=first;
        //Sorting mechanism
        if(x<=curr->getData()){
            newbie->setNext(first);
            first=newbie;
            sorted=true;
        }
        while(sorted==false&&curr->getNext()!=NULL){
            if(x>curr->getData()&&x<=curr->getNext()->getData()){
                newbie->setNext(curr->getNext());
                curr->setNext(newbie);
                sorted=true;
            }
            else{
                curr=curr->getNext();
            }
        }
        if(curr->getNext()==NULL&&sorted==false){
            curr->setNext(newbie);
            newbie->setNext(NULL);
        }


        /*while(curr->getNext()!=NULL){
            curr=curr->getNext();
        }
        curr->setNext(new ListNode(x,NULL));
    */}
}

void List::menu(){
    int indata,input;

    while(1==1){
        cout<<"(1) Insert a value to the list"<<endl;
        cout<<"(2) Print the List"<<endl;
        cin>>input;
        if(input==1){
            cout<<"Enter the value to be inserted: ";
            cin>>indata;
            insert(indata);
        }
        else if(input==2){
            print();
        }
    }

}

int main(){
    List l;
    l.menu();
    return 0;
}
