//Harshal Singh

#include<iostream>
#include<iomanip>
#include<stdlib.h>
#include<stdio.h>
#include<windows.h>

using namespace std;

//RED IS 0, BLACK IS 1

HANDLE console = GetStdHandle(STD_OUTPUT_HANDLE);


COORD coord={0,0};
void gotoxy(int x,int y){
    coord.X=x;
    coord.Y=y;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE),coord);
}

class Piece{
    private:
        int x,y,color,king,active;
    public:
        Piece(){
            x=-1,y=-1,color=0,king=0,active=1;
        }
        int getx(){
            return x;
        }
        int gety(){
            return y;
        }
        int getColor(){
            return color;
        }
        int getKing(){
            return king;
        }
        int getActive(){
            return active;
        }
        void set(int x_pos, int y_pos, int c){//INITIAL SETTING OF PIECE
            x=x_pos, y=y_pos, color=c;
        }
        void set(int x_pos, int y_pos){//MOVEMENT OF PIECE
            x=x_pos, y=y_pos;
        }
        void seta(int a){
            active=a;
        }
        void setk(int k){
            king=k;
        }
        void display();
};

void Piece::display(){
    if(active==1){
        if(color==0&&king==0){
            SetConsoleTextAttribute(console, 12);
            cout<<"r";
            SetConsoleTextAttribute(console, 15);
        }
        else if(color==0&&king==1){
            SetConsoleTextAttribute(console, 12);
            cout<<"R";
            SetConsoleTextAttribute(console, 15);
        }
        else if(color==1&&king==0){
            SetConsoleTextAttribute(console, 9);
            cout<<"b";
            SetConsoleTextAttribute(console, 15);
        }
        else if(color==1&&king==1){
            SetConsoleTextAttribute(console, 9);
            cout<<"B";
            SetConsoleTextAttribute(console, 15);
        }
    }
}

class Board{
    private:
        Piece p[24];
        int x1,x2,y1,y2;//start/end of piece
        int status,redp,blackp,winner;
        int inrange(int x, int y);//is the move inside the board
        int pAtLoc(int x, int y);//can the move happen b/c there arent any pieces there
        int forceJump(int x, int y);//can the peice jump there
        void display(); //show that board and pieces
        void move(int temp);//combines the other functions to make the peice move
        void turn();//switches turn, shows whether there is a draw or not
        int validjump(int x, int y, int temp, int &taken);//can the jump happen?
        void jump(int x,int y, int temp, int taken);//enables jumping
        void getCoords();//????
    public:
        Board();
        void execute();
};

int Board::inrange(int x2, int y2){
    if(x2<=7&&y2<=7){
        return 1;
    }
    else{
        return 0;
    }
}

int Board::pAtLoc(int x2,int y2){
    bool ploc=false;
    for(int c=0;c<24;c++){
        if(p[c].getx()==x2&&p[c].gety()==y2){
            ploc=true;
        }
    }
    if(ploc==true){
        return 1;
    }
    else{
        return 0;
    }

}

int Board::forceJump(int x2, int y2){
    for(int c=0;c<24;c++){
        //EVERYTIME, CHECK BOTH/ALL 4 PLACE WITH INRANGE,PATLOC, AND VALIDJUMP. IF ALL TRUE, THEN RETURN 0
        if(p[c].getColor()==1){
            if(inrange(p[c].getx()+2,p[c].gety()+2)==1&&pAtLoc(p[c].getx()+2,p[c].gety()+2)==0&&validjump(p[c].getx()+2,p[c].gety()+2,c,1)==1){
                return 1;
            }
            else if(inrange(p[c].getx()-2,p[c].gety()+2)==1&&pAtLoc(p[c].getx()-2,p[c].gety()+2)==0&&validjump(p[c].getx()-2,p[c].gety()+2,c,1)==1){
                return 1;
            }
        if(p[c].getColor()==0){
            if(inrange(p[c].getx()+2,p[c].gety()-2)==1&&pAtLoc(p[c].getx()+2,p[c].gety()-2)==0&&validjump(p[c].getx()+2,p[c].gety()-2,c,1)==1){
                return 1;
            }
            else if(inrange(p[c].getx()-2,p[c].gety()+2)==1&&pAtLoc(p[c].getx()-2,p[c].gety()+2)==0&&validjump(p[c].getx()-2,p[c].gety()+2,c,1)==1){
                return 1;
            }

        }
    }
    return 0;
}

void Board::display(){
    bool empty=false;
    SetConsoleTextAttribute(console, 15);
    cout<<" X  0   1   2   3   4   5   6   7"<<endl;
    cout<<"Y";

    for(int c=0;c<8;c++){

        cout<<endl<<"  ---------------------------------";
        cout<<endl;
        cout<<c<<" ";
        for(int j=0;j<8;j++){
            cout<<"| ";
            for(int k=0;k<24;k++){
                if (p[k].getx()==j&&p[k].gety()==c){
                    p[k].display();
                    empty=false;
                    break;
                }
                else{
                    empty=true;
                }
            }
            if (empty==true){
                cout<<" ";
                empty=false;
            }
            cout<<" ";
        }
        cout<<"|";
    }
    cout<<endl<<"  ---------------------------------"<<endl;

    /*for(int k=0;k<24;k++){
        gotoxy(3*p[k].getx(),3*p[k].gety());
        p[k].display();
    }
    gotoxy(50,50);
*/
}

void Board::move(int temp){
    int redo=0,possible,taken;


    while(redo==0){
        redo=1;
        cout<<"Where do you want it to go?(X,Y)"<<endl;
        cout<<"If you want to pick another piece, enter 10 for either input"<<endl;
        cin>>x2;
        cin>>y2;

        if(x2==10||y2==10){
            turn();
        }

        else{
            if(p[temp].getKing()==0){
                if((x2==x1+1||x2==x1-1)&&((p[temp].getColor()==0&&(y2==y1+1))||(p[temp].getColor()==1&&(y2==y1-1)))){
                    possible=1;
                }
                else{
                    possible=0;
                }
            }
            else{
                if((x2==x1+1||x2==x1-1)&&(y2==y1+1||y2==y1-1)){
                    possible=1;
                }
                else{
                    possible=0;
                }
            }

            if(inrange(x2,y2)==1&&pAtLoc(x2,y2)==0){//ADD SPACE EMPTY HERE AS YOU GO THROUGH IT
                 if(possible==1){
                    p[temp].set(x2,y2);
                    redo=1;
                 }
                 else{
                    if(validjump(x2,y2,temp,taken)==1){
                        jump(x2,y2,temp,taken);
                        redo=1;
                    }
                    else{
                        cout<<"This is not legal. Please redo."<<endl;
                        redo=0;
                    }
                 }
            }
            else{
                cout<<"This is not legal. Please redo."<<endl;
                redo=0;
            }
        }
    }
}

int Board::validjump(int x2, int y2, int temp, int &taken){
    int possible;

        if(p[temp].getKing()==0){
            if((x2==x1+2||x2==x1-2)&&((p[temp].getColor()==0&&(y2==y1+2))||(p[temp].getColor()==1&&(y2==y1-2)))){
                possible= 1;
            }
            else{
                possible= 0;
            }
        }
        else{
            if((x2==x1+2||x2==x1-2)&&(y2==y1+2||y2==y1-2)){
                possible= 1;
            }
            else{
                possible= 0;
            }
        }
    if(possible==1){
        for(int c=0;c<24;c++){
            if(p[c].getx()==((x1+x2)/2)&&p[c].gety()==((y1+y2)/2)&&p[c].getColor()!=p[temp].getColor()){
                taken=c;
                return 1;
                break;
            }
            else{

            }
        }
    }
    else{
        return 0;
    }
}

void Board::jump(int x2, int y2, int temp, int taken){

    p[taken].seta(0);
    p[taken].set(-1,-1);
    p[temp].set(x2,y2);


}

void Board::turn(){

    int c,temp;
    bool piececheck;

    if(status%2==0){
        //Red Turn
        cout<<"Red Turn"<<endl;
        do{
            cout<<"What piece do you want to move?(X,Y):"<<endl;
            cin>>x1;
            cin>>y1;
            for(c=0;c<24;c++){
                if(p[c].getx()==x1&&p[c].gety()==y1&&p[c].getColor()==0){
                    temp=c;
                    piececheck=true;
                    break;
                }
            }
            if(c==24){
                cout<<"There is no piece of yours here, try again"<<endl;
                piececheck=false;
            }
        }while(piececheck==false);

        move(temp);
        status++;
    }
    else if(status%2==1){
        //Black Turn
        cout<<"Blue Turn"<<endl;
        do{
            cout<<"What piece do you want to move? (X,Y):"<<endl;
            cin>>x1;
            cin>>y1;
            for(c=0;c<24;c++){
                if(p[c].getx()==x1&&p[c].gety()==y1&&p[c].getColor()==1){
                    temp=c;
                    piececheck=true;
                    break;
                }
            }
            if(c==24){
                cout<<"There is no piece of yours here, try again"<<endl;
                piececheck=false;
            }
        }while(piececheck==false);

        move(temp);
        status++;
    }

    for(int c=0;c<24;c++){
        if((p[c].gety()==7&&p[c].getColor()==0)||(p[c].gety()==0&&p[c].getColor()==1)){
            p[c].setk(1);
        }
    }

}

void Board::getCoords(){

}

Board::Board(){
    p[0].set(0,0,0);
    p[1].set(2,0,0);
    p[2].set(4,0,0);
    p[3].set(6,0,0);
    p[4].set(1,1,0);
    p[5].set(3,1,0);
    p[6].set(4,4,0);
    p[7].set(7,1,0);
    p[8].set(0,2,0);
    p[9].set(2,2,0);
    p[10].set(4,2,0);
    p[11].set(6,2,0);

    p[12].set(1,5,1);
    p[13].set(3,5,1);
    p[14].set(5,5,1);
    p[15].set(7,5,1);
    p[16].set(0,6,1);
    p[17].set(2,6,1);
    p[18].set(4,6,1);
    p[19].set(6,6,1);
    p[20].set(1,7,1);
    p[21].set(3,7,1);
    p[22].set(5,7,1);
    p[23].set(7,7,1);

    winner=2;
}

void Board::execute(){

    cout<<"Who wants to start? Red=0 Blue=1"<<endl;
    cin>>status;
    system("CLS");
    if(forceJump(1,1)==1){
        cout<<"swag";
    }


    while(winner==2){
        redp=0;
        blackp=0;
        for(int c=0;c<24;c++){
            if(p[c].getx()!=-1&&p[c].gety()!=-1&&p[c].getColor()==0){
                redp++;
            }
            else if(p[c].getx()!=-1&&p[c].gety()!=-1&&p[c].getColor()==1){
                blackp++;
            }
        }
        if (redp==0){
            winner=0;
        }
        else if (blackp==0){
            winner=1;
        }
        else{
            display();
            turn();
            system("CLS");
        }
    }
    system("CLS");
    if (winner==0){
        cout<<"Blue wins!"<<endl;
    }//NEED CASE FOR DRAW
    else{
        cout<<"Red wins!"<<endl;
    }
}


int main(){
    Board b;
    b.execute();
    return 0;
}
