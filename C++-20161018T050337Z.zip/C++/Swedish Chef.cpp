//Harshal Singh

//#include "H:\My Documents\C++\myfunctions.h"
#include <string.h>
#include <iostream>
#include <fstream>

using namespace std;

class Swedish {
    private:
        string phrase;
        string swedPhrase;
    public:
        Swedish();
        string getPhrase();
        string getTranslate();
        void setPhrase(string);
        void setSwed(string);
        void translate(string);
        void print();
};

Swedish::Swedish(){
    phrase="";
    swedPhrase="";
}
string Swedish::getPhrase(){
    return phrase;
}
string Swedish::getTranslate(){
    return swedPhrase;
}
void Swedish::setPhrase(string p){
    phrase=p;
}
void Swedish::setSwed(string inpswedish){
    swedPhrase=inpswedish;
}
void Swedish::translate(string p){
    //Translate
    swedPhrase=p;
    bool bork=false;
    bool icheck=false;
    if(p.find(".")!=string::npos){
        bork=true;
        p.erase(p.size()-1,1);
    }
    for(int c=0; c<=p.size(); c++){

        if(p[c]=='T'&&p[c+1]=='H'&&p[c+2]=='E'){
            p.erase(c,3);
            p.insert(c,"ZEE");
            c=c+2;
        }
        else if(p[c]=='A'&&p[c+1]=='N'){
            p.erase(c,2);
            p.insert(c,"UN");
            c++;
        }
        else if(p[c]=='A'&&p[c+1]=='U'){
            p.erase(c,2);
            p.insert(c,"OO");
            c++;
        }
        else if(p[c]=='A'&&(p[c+1]!=' '&&p[c+1]!=NULL)){
            p.erase(c,1);
            p.insert(c,"E");
        }
        else if(p[c]=='O'&&p[c+1]=='W'){
            p.erase(c,2);
            p.insert(c,"OO");
            c++;
        }
        else if(p[c]=='O'){
            p.erase(c,1);
            p.insert(c,"U");
        }
        else if(p[c]=='I'&&icheck==false&&(p[c-1]!=' '&&c!=0)){
            p.erase(c,1);
            p.insert(c,"EE");
            c++;
            icheck=true;
        }
        else if(p[c]=='E'&&p[c+1]=='N'&&(p[c+2]==' '||p[c+2]==NULL)){
            p.erase(c,2);
            p.insert(c,"EE");
            c+=2;
        }
        else if(p[c]=='E'&&(p[c+1]==' '||p[c+1]==NULL)){
            p.erase(c,1);
            p.insert(c,"E-A");
            c+=2;
        }
        else if(p[c]=='E'&&(p[c-1]==' '||c==0)){
            p.erase(c,1);
            p.insert(c,"I");
        }
        else if(p[c]=='U'){
            p.erase(c,1);
            p.insert(c,"OO");
            c++;
        }
    }
    swedPhrase=p;
    if(bork==true){
        swedPhrase += ". Bork Bork Bork!";
    }
}
void Swedish::print(){
    cout<<endl;
    cout<<"E: "<<phrase<<endl;
    cout<<"S: "<<swedPhrase<<endl;
}

int main(){
    string inpphrase;
    string inpswed;
    Swedish theProject;

    ifstream inputfile;
    inputfile.open("S://Public/Potter/swed3.txt");
    getline(inputfile,inpphrase);
    inpphrase="THE ANSWER.";
    //cout<<inpphrase;

    theProject.setPhrase(inpphrase);
    theProject.translate(inpphrase);
    theProject.print();

    inputfile.close();
    return 0;
}
