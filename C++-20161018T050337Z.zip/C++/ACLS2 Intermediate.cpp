#include <iostream>
#include <string.h>
#include <vector>
#include <algorithm>
#include <stdio.h>
#include <stdlib.h>

using namespace std;

vector<string> values;
vector<string>result;
int modifier;

void display(vector<string>values){
    cout<<"'(";
    for(int k=0;k<values.size();k++){
        if(k!=values.size()-1){
            cout<<values[k]<<" ";
        }
        else{
            cout<<values[k];
        }
    }

    cout<<")"<<endl;
}

void translate1(string input){
    string atom;
    //vector<string>values;
    int c=0;

    input.erase(0,1);

    for(c=0; c<input.size()-1;c++){
        if(input[c]!=' '){
            while(input[c]!=' '&&input[c]!=')'&&input[c]!='('){
                atom+=input[c];
                c++;
            }
            if(atom!=""){
                values.push_back(atom);
                atom.clear();
            }

        }
    }
    //display();
}

void rev(){
    reverse(values.begin(),values.end());
    display(values);
    reverse(values.begin(),values.end());
}

void group(int operation){
    string indiv;
    int counter=1;
    string group;
    vector<string> result;
    vector<string> temp=values;

    for(int c=0;c<values.size()-1;c++){


        if(temp[c]==temp[c+1]){
            if(c==values.size()-2){
                counter++;
            }
            else{
                counter++;
            }
        }

        if(temp[c]!=temp[c+1]||c==values.size()-2){
            if(counter==1){
                if(operation==3){
                    group=" "+temp[c]+" ";
                }
                else{
                    group="(1 "+temp[c]+")";
                }
            }
            if(counter==2){
                group="(2 "+temp[c]+")";
            }
            if(counter==3){
                group="(3 "+temp[c]+")";
            }
            if(counter==4){
                group="(4 "+temp[c]+")";
            }
            if(counter==5){
                group="(5 "+temp[c]+")";
            }
            if(counter==6){
                group="(6 "+temp[c]+")";
            }
            if(counter==7){
                group="(7 "+temp[c]+")";
            }
            if(counter==8){
                group="(8 "+temp[c]+")";
            }
            if(counter==9){
                group="(9 "+temp[c]+")";
            }
            counter=1;
            result.push_back(group);
        }
    }
    display(result);
}

void translate2(string input){
    input.erase(0,2);
    string atom="";
    for(int c=0;c<input.size();c++){
        if(input[c]!=' '||input[c]==')'){
            atom=atom+input[c];
        }
        else{
            values.push_back(atom);
            atom.clear();
        }
    }
    modifier=input[input.size()-2];
    display(values);
}

void remove(){
    //easy
}

int main(){
    values.clear();
    string input;

    cout<<"Second input:";
    getline(cin,input);
    input="'((4 a) (1 b) (2 c) 2)";
    translate2(input);
    //group(2);
    values.clear();

    return 0;
}
