//Harshal Singh
//Period 4

#include<iostream>
#include<vector>
#include<algorithm>

using namespace std;

class Binary{
    private:
        vector<int>B1;
        int rshift;
    public:
        void input();
        vector <int> getVector();
        void operator ! ();
        void operator > (int rshift);
        void operator + (Binary);
};


void Binary::input(){
    string tempnumber;
    cout<<"Binary number:";
    cin>>tempnumber;
    for(int c=0;c<tempnumber.size();c++){
        if(tempnumber[c]=='0'){
            B1.push_back(0);
        }
        else{
            B1.push_back(1);
        }
    }

}

vector<int>Binary::getVector(){
    return B1;
}

void Binary::operator!(){
    cout<<"!B1 is implemented"<<endl;
    for(int c=0;c<B1.size();c++){
        if(B1[c]==1){
            cout<<"0";
        }
        else{
            cout<<"1";
        }
    }
    cout<<endl;
}

void Binary::operator>(int rshift){

    for(int c=0;c<rshift;c++){
        cout<<"0";
    }
    for(int c=0;c<(B1.size()-rshift);c++){
        cout<<B1[c];
    }
    cout<<endl;
}

void Binary::operator+(Binary b){

    vector<int>B2=b.getVector();

    for(int c=0;c<B1.size();c++){
        if(B1[c]==1||B2[c]==1){
            cout<<"1";
        }
        else{
            cout<<"0";
        }
    }
    cout<<endl;
}


int main(){
    Binary a,b;
    char operation;
    int shifter;

    a.input();
    while(1==1){
        cout<<"What operation would you like to perform?"<<endl;
        cin>>operation;
        if(operation=='!'){
            !a;
        }
        else if(operation=='>'){
            cout<<"Please enter the R-Shift value:";
            cin>>shifter;
            cout<<"B1 > "<<shifter<<" is being implemented"<<endl;
            a>shifter;
        }
        else if(operation=='+'){
            cout<<"Please enter the other Binary Number"<<endl;
            b.input();
            cout<<"B1+B2 is being implemented"<<endl;
            a+b;
        }
    }
    return 0;
}
