#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

class Binary{
    private:
        vector<int>number;
        vector<int>sum;
    public:
        Binary();
        void input();
        void display();
        vector <int> getVector();
        void operator+(Binary);
        void hex();
};

Binary::Binary(){
    number.clear();
}

void Binary::input(){
    string tempnumber;
    cout<<"Enter the binary number:";
    cin>>tempnumber;
    for(int c=0;c<tempnumber.size();c++){
        if(tempnumber[c]=='0'){
            number.push_back(0);
        }
        else{
            number.push_back(1);
        }
    }
}

void Binary::display(){
    for(int c=0;c<number.size();c++){
        cout<<number[c];
    }
    cout<<endl;
}

vector <int> Binary::getVector(){
    return number;
}

void Binary::operator+(Binary secondnumber){
    //vector <int> sum;
    int tempsum;
    int checkcarry;
    int tempval;
    vector <int> tempfirstnumber=number;
    reverse(tempfirstnumber.begin(),tempfirstnumber.end());
    vector <int> tempsecondnumber=secondnumber.getVector();
    reverse(tempsecondnumber.begin(),tempsecondnumber.end());

    cout<<"Binary Sum:";

    //The reason we use push back is because its already reversed
    if(tempfirstnumber.size()>tempsecondnumber.size()){
        tempval=(tempfirstnumber.size()-tempsecondnumber.size());
        for(int c=0;c<tempval;c++){
            tempsecondnumber.push_back(0);
        }
    }
    else if(tempfirstnumber.size()<tempsecondnumber.size()){
        tempval=(tempsecondnumber.size()-tempfirstnumber.size());
        for(int c=0;c<tempval;c++){
            tempfirstnumber.push_back(0);
        }
    }

    for(int c=0;c<tempfirstnumber.size();c++){
        tempsum=tempfirstnumber[c]+tempsecondnumber[c];
        if(checkcarry==1){
            tempsum++;
        }
        else if(checkcarry==2){
            tempsum++;
        }

        if(tempsum==0||tempsum==1){
            checkcarry=0;
        }
        else if(tempsum==2){
            checkcarry=1;
            tempsum=0;
        }
        else if(tempsum==3){
            checkcarry=2;
            tempsum=1;
        }
        sum.push_back(tempsum);
        if(c==tempfirstnumber.size()-1&&checkcarry!=0){
            //cout<<"yes";
            sum.push_back(1);
        }
    }
    reverse(sum.begin(),sum.end());
    for(int c=0;c<sum.size();c++){
        cout<<sum[c];
    }

}

void Binary::hex(){
    int group[4];
    int i,hexsum=0;
    vector<int> tempsum=sum;
    vector<char> hex;

    cout<<"Hex Sum:";

    reverse(tempsum.begin(),tempsum.end());
    while (tempsum.size()%4!=0){
        tempsum.push_back(0);
    }
    reverse(tempsum.begin(),tempsum.end());

    //hex
    int tempsize=tempsum.size();
    for(int c=0;c<tempsize/4;c++){
        for(i=0;i<4;i++){
            group[i]=tempsum[i];
            //cout<<tempsum[i]<<endl;
        }
        hexsum=group[0]*(8)+group[1]*4+group[2]*2+group[3];
        //how to put an int into a char vector
        if(hexsum<=9){
            hexsum+=48;
            hex.push_back(char(hexsum));
        }
        else if(hexsum==10){
            hex.push_back('A');
        }
        else if(hexsum==11){
            hex.push_back('B');
        }
        else if(hexsum==12){
            hex.push_back('C');
        }
        else if(hexsum==13){
            hex.push_back('D');
        }
        else if(hexsum==14){
            hex.push_back('E');
        }
        else if(hexsum==15){
            hex.push_back('F');
        }

        reverse(tempsum.begin(),tempsum.end());
        tempsum.pop_back();
        tempsum.pop_back();
        tempsum.pop_back();
        tempsum.pop_back();
        reverse(tempsum.begin(),tempsum.end());
    }

    for(int c=0;c<hex.size();c++){
        cout<<hex[c];
    }

}

int main(){
    Binary a,b;

    a.input();
    b.input();
    cout<<endl;
    cout<<"Binary 1:";
    a.display();
    cout<<"Binary 2:";
    b.display();

    a+b;
    cout<<endl;
    a.hex();
    cout<<endl;

    return 0;
}
