//Harshal Singh

#include<iostream>
#include<iomanip>

using namespace std;

char city1,city2,cartype,roadtype;
double cost;
double tempmin;

int miles;
double price;

void input(){
    cin>>city1;
    cin>>city2;
    cin>>cartype;
    cin>>roadtype;
    cin>>cost;
}

void findMilage(){
    int distances[6]={450,140,120,320,250,80};
    int difference=int(city2)-int(city1);
    miles=0;
    for(int c=0;c<difference;c++){
        miles+=distances[int(city1)+c-65];
    }

}

void findTime(){
    double mph;
    double mpm;
    tempmin=0;
    if(roadtype=='I'){
        mph=65;
    }
    else if(roadtype=='H'){
        mph=60;
    }
    else if(roadtype=='M'){
        mph=55;
    }
    else{
        mph=45;
    }
    mpm=mph/60;
    tempmin=miles/mpm;
    if(tempmin-int(tempmin)>=.5){
        tempmin++;
    }
    //cout<<tempmin<<endl;
    //cout<<minuteselapsed%60<<endl;
    //cout<<(minuteselapsed-(minuteselapsed%60))/60<<endl;

}

void findPrice(){
    price=0;
    int mpg;
    if(cartype=='C'){
        mpg=28;
    }
    else if(cartype=='M'){
        mpg=25;
    }
    else if(cartype=='F'){
        mpg=22;
    }
    else {
        mpg=20;
    }
    price=(double(miles)/double(mpg))*cost;

}

void output(){
    int hour=int((tempmin-(int(tempmin)%60))/60);
    int minute=(int(tempmin)%60);
    cout<<miles<<",";
    if(int((tempmin-(int(tempmin)%60))/60)<10){
        cout<<"0";
    }
    cout<<hour<<":";
    if(minute<10){
        cout<<"0";
    }
    cout<<setprecision(2)<<minute<<",$"<<fixed<<price<<endl;
}

int main(){

    for(int c=0;c<5;c++){
        input();
        findMilage();
        findTime();
        findPrice();
        output();
    }
    return 0;
}
