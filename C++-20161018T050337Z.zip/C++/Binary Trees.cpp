#include<iostream>
#include<string>
#include<windows.h>
#include <stdio.h>

using namespace std;

COORD coord={0,0};

void gotoxy(int x,int y){
    coord.X=x;
    coord.Y=y;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE),coord);
}

class BNode{
    private:
        char data;
        BNode *left;
        BNode *right;
        int depth;
    public:
        BNode(char d,BNode *l,BNode *r,int dep){
            data=d;
            left=l;
            right=r;
            depth=dep;
        }
        char getData(){
            return data;
        }
        BNode *getLeft(){
            return left;
        }
        BNode *getRight(){
            return right;
        }
        int getDepth(){
            return depth;
        }
        void setLeft(BNode *l){
            left=l;
        }
        void setRight(BNode *r){
            right=r;
        }
};

class BTree{
    private:
        BNode *first;
    public:
        BTree(){
            first=NULL;
        }
        BNode getFirst(){
            return *first;
        }
        void insert(char x);
        void print(BNode *curr);
        void realprint(BNode *curr,int n,int d);
        void execute();
};

void BTree::insert(char x){
    int n=0;
    if(first==NULL){
        first=new BNode(x,NULL,NULL,0);
    }
    else{
        BNode *curr=first;
        bool exit=false;
        n=0;
        do{
            n++;
            if(x<=curr->getData()&&curr->getLeft()!=NULL){
                curr=curr->getLeft();
            }
            else if(x>curr->getData()&&curr->getRight()!=NULL){
                curr=curr->getRight();
            }
            else{
                exit=true;
            }
        }while(exit==false);
        if(x>curr->getData()){
            curr->setRight(new BNode(x,NULL,NULL,n));
        }
        if(x<=curr->getData()){
            curr->setLeft(new BNode(x,NULL,NULL,n));
        }
    }
}

void BTree::print(BNode *curr){
    int max=0;

    if(curr->getLeft()!=NULL){
        print(curr->getLeft());
    }

    cout<<curr->getData()<<" ";

    if(curr->getRight()!=NULL){
        print(curr->getRight());
    }

    //cout<<max;
}

void BTree::realprint(BNode *curr,int n,int d){

    if(curr->getLeft()!=NULL){
        realprint(curr->getLeft(),n-d,d--);
    }
    gotoxy(n,curr->getDepth()+2);
    cout<<curr->getData();
    if(curr->getRight()!=NULL){
        realprint(curr->getRight(),n+d,d--);
    }

    cout<<endl;
}

void BTree::execute(){
    print(first);
    cout<<endl;
    realprint(first,40,7);
}

int main(){
    string input;
    BTree t;


    cin>>input;

    for(int c=0;c<input.size();c++){
        t.insert(input[c]);
    }
    t.execute();

    return 0;
}
