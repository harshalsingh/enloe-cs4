#include <iostream>
#include <string>

using namespace std;

class Node{
    private:
        char data;
        Node *left;
        Node *right;
        int solve;//temp solve will be 999
    public:
        Node(char d,Node *l,Node *r,int sol){
            data=d;
            left=l;
            right=r;
            solve=sol;
        }
        char getData(){
            return data;
        }
        Node *getLeft(){
            return left;
        }
        Node *getRight(){
            return right;
        }
        int getSolve(){
            //big solving function ay
        }
        void setLeft(Node *l){
            left=l;
        }
        void setRight(Node *r){
            right=r;
        }
};

class ETree{
    private:
        Node *first;
    public:
        ETree(){
            first=NULL;
        }
        Node getFirst(){
            return *first;
        }
        void input();
        void print(Node *curr);
        void solve();
        void execute();
};

void ETree::input(){
    string temp;
    cin>>temp;

    first=new Node(temp[0],NULL,NULL,999);

    for(int c=1;c<temp.size();c++){
        //lol
    }

}

void ETree::execute(){
    input();
}


int main(){
    ETree tree;
    tree.execute();
    return 0;
}
