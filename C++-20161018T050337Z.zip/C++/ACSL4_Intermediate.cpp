//Harshal Singh
#include<iostream>
#include<string>
#include<vector>
#include<stdlib.h>
#include<stdio.h>
#include<windows.h>

using namespace std;

bool confirm(vector <int> init,int x){
    //make sure that this value makes the function true
    for(int c=0;c<init.size();c++){
        if (x==init[c]){
            return true;
            break;
        }
    }
    return false;
}

string combine1(int x1,int x2){
    //combine with two things
    string bin[16]={"0000","0001","0010","0011","0100","0101","0110","0111","1000","1001","1010","1011","1100","1101","1110","1111"};
    string final="";
    int xindex=0;

    string s1=bin[x1];
    string s2=bin[x2];

    for(int c=0;c<4;c++){
        if(s1[c]==s2[c]){
            final=final+s1[c];
        }
        else{
            final=final+"x";
        }
    }

    for(int c=0;c<4;c++){
        if(final[c]=='x'){
            xindex++;
        }
    }

    if(xindex>1){
        final="NONE";
    }

    return final;
}

string combine2(string s1,string s2){
    string final="";
    int xindex=0;

    for(int c=0;c<4;c++){
        if(s1[c]==s2[c]){
            final=final+s1[c];
        }
        else{
            final=final+"x";
        }
    }

    for(int c=0;c<4;c++){
        if(final[c]=='x'){
            xindex++;
        }
    }

    if(xindex>2){
        final="NONE";
    }

    return final;
}

void output(string final){
    if(final!="NONE"){
        cout<<final<<", ";
        for(int c=0;c<4;c++){
            if(final[c]=='1'){
                cout<<char(c+65);
            }
            if(final[c]=='0'){
                cout<<char(c+97);
            }
        }
    }
    else {
        cout<<"NONE";
    }
    cout<<endl;
}

int main(){
    int input,inp1[2],inp2[4];
    vector <int> init;
    bool conf=true;

    while(input!=-1){
        cin>>input;
        init.push_back(input);
    }
    system("CLS");
    for(int c=0;c<2;c++){
        cin>>inp1[0];
        cin>>inp1[1];
        if(confirm(init,inp1[0])==true && confirm(init,inp1[1])==true){
            output(combine1(inp1[0],inp1[1]));
        }
        else{
            cout<<"NONE"<<endl;
        }
    }
    for(int c=0;c<3;c++){
        for(int j=0;j<4;j++){
            cin>>inp2[j];
            if(confirm(init,inp2[j])==false){
                bool conf=false;
            }
        }
        if(conf==false){
            cout<<"NONE"<<endl;
        }
        else{
            output(combine2(combine1(inp2[0],inp2[1]),combine1(inp2[2],inp2[3])));
        }
        conf=true;
    }
    return 0;
}
