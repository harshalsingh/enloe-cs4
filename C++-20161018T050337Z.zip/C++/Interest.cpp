//Harshal Singh

#include <iostream>
#include <iomanip>
#include <math.h>

using namespace std;

int main(){
    double principle, rate, compound, n, m;
    long double amount;
    int t;
    int w=20;
    cout<<"Principle=";
    cin>>principle;
    cout<<"Rate=";
    cin>>rate;
    rate=rate*.01;
    cout<<"How it is compounded=";
    cin>>compound;

    cout<<"Year"<<setw(23)<<"Balance"<<endl;

    for (t=1; t<11; t++){
        n=(1+(rate/compound));
        m=compound*t;
        amount=principle*pow(n,m);
        cout<<fixed<<t;
        if(t==10){
            w=w-1;
        }
        cout<<setw(w)<<setprecision(2)<<fixed<<"$"<<amount<<endl;
        amount=0;
    }
    return 0;
}
