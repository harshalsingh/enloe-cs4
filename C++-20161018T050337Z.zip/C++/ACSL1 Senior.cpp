#include<iostream>
#include<string>

using namespace std;

char city1,city2;
int miles,start1,start2,mph1,mph2;
string time1,time2;

void input(){
    cin>>city1;
    cin>>city2;
    cin>>start1;
    cin>>time1;
    cin>>start2;
    cin>>time2;
    cin>>mph1;
    cin>>mph2;
}

void findMilage(){
    int distances[10]={450,140,125,365,250,160,380,0,235,320};
    int difference=int(city2)-int(city1);
    miles=0;
    for(int c=0;c<difference;c++){
        miles+=distances[int(city1)+c-65];
    }
    if(time1=="PM"){
        start1+=12;
    }
    if(time2=="PM"){
        start2+=12;
    }
    int timedif;
    if(start1<start2){
        timedif=start2-start1;
    }
    else if(start1>start2){
        timedif=start1-start2;
    }

    double totmiles=miles;
    if(start1<start2){
        //the second car went first
        totmiles=totmiles-(timedif*mph2);
    }
    else if(start2<start1){
        //first car went first
        totmiles=totmiles-(timedif*mph1);
    }
    double timeelap=totmiles/double(mph1+mph2);

    timeelap=timeelap*60;

    if(start1<start2){
        timeelap+=(timedif*60);
    }
    cout<<timeelap;
    cout<<endl<<int(timeelap)%60;
}

void findTime(){

}

int main(){

    for(int c=0;c<5;c++){
        input();
        findMilage();
    }

    return 0;
}
