#include "H:\My Documents\C++\myfunctions.h"

using namespace std;

const int num=30;


int main(){
    ofstream outputfile;
    int integers[num];
    char characters[num];
    double doubles[num];
    double randdouble;
    int counter=num;

    srand(time(NULL));
    //INTEGER SECTION
    for(int c=0;c<num;c++){
        integers[c]=rand()%32000;
    }
    for(int c=0;c<20;c++){
        cout<<integers[c]<<endl;
    }

    Bubblesort(integers,num);
    cout<<endl;
    //CHAR SECTION
    cout<<endl;
    for(int c=0;c<num;c++){
        characters[c]=char(rand()%256);
    }
    for(int c=0;c<20;c++){
        cout<<characters[c]<<endl;
    }
    Bubblesort(characters,num);
    //DOUBLE SECTION
    cout<<endl;
    //ios::showpoint;
    for(int c=0;c<num;c++){
        randdouble=(rand()%32000);
        randdouble=randdouble/32000;
        doubles[c]=randdouble;
    }
    for(int c=0;c<20;c++){
        cout<<setprecision(4)<<fixed;
        cout<<doubles[c]<<endl;
    }
    Bubblesort(doubles,num);
    cout<<endl;

    outputfile.open("H://outputfile.txt");


    for(int c=1; c<=num; c++){
        outputfile<<integers[c-1]<<" ";
        if(c%10==0){
            outputfile<<endl;
        }
    }
    cout<<endl;
    outputfile<<endl;
    for(int c=1; c<=num; c++){
        outputfile<<characters[c-1]<<" ";
        if(c%10==0){
            outputfile<<endl;
        }
    }
    cout<<endl;
    outputfile<<endl;
    for(int c=1; c<=num; c++){
        outputfile<<setprecision(4)<<fixed<<doubles[c-1]<<" ";
        if(c%10==0){
            outputfile<<endl;
        }
    }
    outputfile.close();
    return 0;
}
