#include <iostream>

using namespace std;

int main(){
    bool board [20][20];

    for(int c=0;c<20;c++){
        for(int k=0;k<20;k++){
            board[c][k]=false;
        }
    }

    while(true){

    }
    return 0;
}
