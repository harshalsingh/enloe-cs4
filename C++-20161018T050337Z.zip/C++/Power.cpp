//Harshal Singh

#include <iostream>

using namespace std;

double product=1;

void exponent(int &base, int &power){
    int b;
    product=1;
    for(b=power; b>0; b--){
        product=base*product;
    }
}

int main(){
    int base;
    int power;
    while(0==0){
        cout<<"Base=";
        cin>>base;
        cout<<"Power=";
        cin>>power;

        cout<<base<<"^"<<power<<" is ";

        if(power>0){
            exponent(base, power);
            cout<<product<<endl;
        }

        else if(power==0){
            if(base==0){
                cout<<"Undefined/Nonexistent"<<endl;
            }
            else{
                product=1;
                cout<<product<<endl;
            }
        }

        else{
            power=power*-1;
            exponent(base, power);
            if (base==1||base==-1){
                cout<<product<<endl;
            }
            else if (base==0){
                cout<<"Undefined"<<endl;
            }
            else if (product>0){
                cout<<"1/"<<product<<" or "<<double(1/product)<<endl;
            }
            else{
                cout<<"-1/"<<-product<<" or "<<double(1/product)<<endl;
            }
        }
    }
    return 0;
}
