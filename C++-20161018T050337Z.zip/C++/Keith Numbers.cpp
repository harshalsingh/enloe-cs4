//Harshal Singh
//Period 4

#include<iostream>
#include<vector>
#include<algorithm>

using namespace std;

class Keith{
    private:
        vector <int> number;
        int seed;
        int seedsize;
    public:
        void input();
        void execute();
};

void Keith::input(){
    int compare=1;
    int initnumber,multiplier=10;
    int size=0;

    cin>>initnumber;
    seed=initnumber;

    while(compare<initnumber){
        compare=compare*10;
        size++;
    }

    seedsize=size;

    //cout<<size<<endl;

    for(int c=1;c<size+1;c++){
        number.push_back(initnumber%multiplier);
        initnumber=initnumber-(initnumber%multiplier);
        initnumber=initnumber/10;
    }

    reverse(number.begin(),number.end());

}

void Keith::execute(){
    int counter=0;
    int sum=0;
    int fibnum;

    while(number[counter]<seed){
        for(int c=0;c<seedsize;c++){
            sum=number[number.size()-c-1]+sum;
        }
        number.push_back(sum);
        //cout<<sum<<endl;
        sum=0;
        counter++;
    }

    if(number[counter]==seed){
        cout<<"Yes, Position:"<<counter+1;
    }
    else if(number[counter]>seed){
        cout<<"No";
    }

}

int main(){
    Keith a;
    a.input();
    a.execute();

    return 0;

}
