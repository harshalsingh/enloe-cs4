//Harshal Singh

#include <iostream>

using namespace std;

int seed1;
int seed2;
int input,sum=0;

void fib(int seed1, int seed2, int input, int &sum){

    if (input==0){
        cout<<sum;
    }
    else{
        sum=seed1+seed2;
        seed1=seed2;
        seed2=sum;
        input--;
        fib(seed1, seed2, input, sum);
    }
}

int main(){

    cout<<"Seed 1:";
	cin>>seed1;
	cout<<"Seed 2:";
	cin>>seed2;
	cout<<"Input:";
	cin>>input;

    if (input==1){
        cout<<seed1;
    }
    else if (input==2){
        cout<<seed2;
    }
    else {
        input=input-2;
        fib(seed1, seed2, input, sum);
    }

    return 0;
}
