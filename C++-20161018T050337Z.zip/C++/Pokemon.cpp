//Harshal Singh

#include<iostream>

using namespace std;
