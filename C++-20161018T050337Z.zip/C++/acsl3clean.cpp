//Harshal Singh

#include<iostream>
#include<vector>

using namespace std;

void isola(){
    int input,pivot,temp,counter,maxtype;
    bool empty=false;
    vector<int> pieces;
    vector<int> diff[8];
    int max=0;
    int additor[8]={7,8,1,-6,-7,-8,-1,6};

    cin>>input;
    pieces.push_back(input);
    while(input>0){
        cin>>input;
        pieces.push_back(input);
    }
    for(int j=0;j<7;j++){
        pivot=pieces[1];empty=false;
        while(empty==false){//DIRECTLY UP
            for(int c=0;c<pieces.size()-1;c++){
                if(pieces[c]==pivot+additor[j]||pivot+7>49||pivot<8||pivot%7==0||pivot%7==1){
                    empty=true;
                }
            }
            if(empty==false){
                diff[j].push_back(pivot+7);
                pivot+=7;
            }
        }
    }
    for(int c=0;c<7;c++){
        if(diff[c].size()>max){
            maxtype=c;
            max=diff[c].size();
        }
    }
    if(max==0){
        cout<<"NONE"<<endl;
    }
    else{
        vector<int>path=diff[maxtype];
        for(int c=0;c<path.size()-1;c++){
            cout<<path[c]<<",";
        }
        cout<<path[path.size()-1]<<endl;
    }
}

int main(){
    for(int c=0;c<5;c++){
        isola();
    }
    return 0;
}
