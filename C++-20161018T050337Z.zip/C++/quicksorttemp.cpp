#include<iostream>

using namespace std;

const int numnumbers=10;

void swap(int &s1, int &s2){
    int temp;
    temp=s1;
    s1=s2;
    s2=temp;
}

void qsort(int array[],int s, int e){
    int pivot;
    int left=s;
    int right=e;
    if(e-s<2){
        if(array[s]>array[e]){
            swap(array[s],array[e]);
        }
    }

    else{
        pivot=array[s-1];

        while(left!=right){

            while(array[left]<=pivot&&left!=right){
                left++;
            }

            while(array[right]>pivot&&left!=right){
                right--;
            }
            if(left<right){
                swap(array[left],array[right]);
            }
        }
        if(left==right){
            cout<<"yes"<<":"<<e;
            if(right==s){
                //LOW PIVOT
                //cout<<"Low pivot";
                qsort(array,s+1, e);
            }
            if(left==e){
                //cout<<"High pivot";
                qsort(array,s,e-1);
            }
            else{
                //cout<<"Mid pivot";
                //cout<<left;
                //cout<<"swapping"<<array[s]<<"with"<<array[left-1]<<endl;
                swap(array[s-1],array[left-1]);

                //cout<<endl<<array[s]<<":"<<array[left-2]<<":"<<s<<":"<<left-2;
                //cout<<s+1<<left-2<<endl;
                qsort(array,s,left-2);



                qsort(array, left+1,e);
                //cout<<endl<<array[left+1]<<":"<<array[e]<<endl;
            }
        }

    }
}

int main(){
    int start=1;
    int end=numnumbers-1;
    int values[numnumbers]={4,1,2,8,3,0,9,5,5,4};
    for(int c=0; c<numnumbers; c++){
        cout<<values[c]<<" ";
    }
    qsort(values,start,end);
    cout<<endl;
    for(int c=0; c<numnumbers; c++){
        cout<<values[c]<<" ";
    }

    return 0;

}
