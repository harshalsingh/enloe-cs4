//Harshal Singh

#include<iostream>
#include<stdlib.h>

using namespace std;

int x;

class ListNode{
    private:
        int data;
        ListNode *next;
    public:
        ListNode(int d,ListNode *n){
            data=d;
            next=n;
        }
        int getData(){
            return data;
        }
        ListNode *getNext(){
            return next;
        }
        void setNext(ListNode *n){
            next=n;
        }
};

class ListStack{
    private:
        ListNode *first;
    public:
        ListStack(){
            first=NULL;
        }
        void insert(int x);
        int gettop();
        void remove();
        void print();
        void menu();
};

void ListStack::insert(int x){
    if(first==NULL){
        first=new ListNode(x,NULL);
    }
    else{
        ListNode *curr=first;
        while(curr->getNext()!=NULL){
            curr=curr->getNext();
        }
        curr->setNext(new ListNode(x,NULL));
    }
}

int ListStack::gettop(){
    ListNode *curr=first;
    if(curr->getNext()==NULL){
        return curr->getData();
    }
    else{
        while(curr->getNext()->getNext()!=NULL){
            curr=curr->getNext();
        }
        return curr->getNext()->getData();
    }
}

void ListStack::remove(){
    ListNode *curr=first;
    if(curr->getNext()==NULL){
        first=NULL;
    }
    else{
        while(curr->getNext()->getNext()!=NULL){
            curr=curr->getNext();
        }
        curr->setNext(NULL);
    }
}

void ListStack::print(){
    ListNode *curr=first;
    if(curr!=NULL){
        do{
            cout<<curr->getData();
            cout<<" ";
            curr=curr->getNext();
        }while(curr!=NULL);
    }
    cout<<endl;
}

class Tower{
    private:
        ListStack S1;
        ListStack S2;
        ListStack S3;
    public:
        Tower(int x){
            for(int c=x;c>0;c--){
                S1.insert(c);
            }
        }
        void move1(int s, int e);
        void move2(int s, int e, int t);
        void move3(int s, int e, int t);
        void move4(int s, int e, int t);
        void move5(int s, int e, int t);
        void execute();
};

void Tower::move1(int s,int e){
    int temp,stop;
    //cin>>stop;
    system("PAUSE");
    system("CLS");
    if(s==1){
        temp=S1.gettop();
        S1.remove();
    }
    else if(s==2){
        temp=S2.gettop();
        S2.remove();
    }
    else if(s==3){
        temp=S3.gettop();
        S3.remove();
    }

    if(e==1){
        S1.insert(temp);
    }
    else if(e==2){
        S2.insert(temp);
    }
    else if(e==3){
        S3.insert(temp);
    }
    //Printing portion
    cout<<"S1:";
    S1.print();
    cout<<"S2:";
    S2.print();
    cout<<"S3:";
    S3.print();
    cout<<endl;
}

void Tower::move2(int s, int e, int t){
    move1(s,t);
    move1(s,e);
    move1(t,e);
}

void Tower::move3(int s, int e, int t){
    move2(s,t,e);
    move1(s,e);
    move2(t,e,s);
}

void Tower::move4(int s, int e, int t){
    move3(s,t,e);
    move1(s,e);
    move3(t,e,s);
}

void Tower::move5(int s, int e, int t){
    move4(s,t,e);
    move1(s,e);
    move4(t,e,s);
}

void Tower::execute(){
    int temp;

    cout<<"S1:";
    S1.print();
    cout<<"S2:";
    S2.print();
    cout<<"S3:";
    S3.print();

    cin>>temp;
    system("CLS");

    if(x==1){
        move1(1,3);
    }
    else if(x==2){
        move2(1,3,2);
    }
    else if(x==3){
        move3(1,3,2);
    }
    else if(x==4){
        move4(1,3,2);
    }
    else {
        move5(1,3,2);
    }
    cout<<"The tower is completed!"<<endl;
}

int main(){
    cout<<"Enter your tower height:";
    cin>>x;
//replace set with the stacks themselves
    Tower t(x);
    t.execute();

    return 0;
}
