#include <iostream>

using namespace std;

class ListNode{
    private:
        int data;
        ListNode *next;
    public:
        ListNode(int d,ListNode *n){
            data=d;
            next=n;
        }
        int getData(){
            return data;
        }
        ListNode *getNext(){
            return next;
        }
        void setNext(ListNode *n){
            next=n;
        }
};

class ListStack{
    private:
        ListNode *first;
    public:
        ListStack(){
            first=NULL;
        }
        void insert(int x);
        void remove();
        void print();
};

void ListStack::insert(int x){
    if(first==NULL){
        first=new ListNode(x,NULL);
    }
    else{
        ListNode *curr=first;
        while(curr->getNext()!=NULL){
            curr=curr->getNext();
        }
        curr->setNext(new ListNode(x,NULL));
    }
}

void ListStack::remove(){
    ListNode *curr=first;
    while(curr->getNext()->getNext()!=NULL){
        curr=curr->getNext();
    }
    curr->setNext(NULL);
}

void ListStack::print(){
    ListNode *curr=first;
    do{
        cout<<curr->getData();
        cout<<" ";
        curr=curr->getNext();
    }while(curr!=NULL);
    cout<<endl;
}

int main(){
    ListStack l;
    for(int c=5;c>0;c--){
        l.insert(c);
    }
    l.print();
    l.remove();
    l.print();
    return 0;
}
